insert into category (category_id, primary_name, secondary_name) values
(1, 'test', 'fake'),
(2, 'apple', 'macos'),
(3, 'oracle', 'java'),
(4, 'programming', 'rust');
